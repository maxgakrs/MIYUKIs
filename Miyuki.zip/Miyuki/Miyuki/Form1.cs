﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace Miyuki
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        public void atk()//เม็ดตอทที่ใช้สำหรับสั่งให้เปิดwebgoogle30หน้าขึ้นมา
        {
            for (int i = 0; i < 30; i++)//ทำลูปโดยเงื่อนไขว่า i<30 คือเราจะทำไปเรื่อยๆจนกว่าiจะเท่ากับ30
            {
                Process.Start("https://www.Google.co.th");//สั่งให้เปิดgoogleขึ้นมา1หน้า
            }        
        }

        private void button1_Click(object sender, EventArgs e)//เมื่อปุ่มbutton1ถูกคลิก 
        {
            switch (textBox1.Text)//เช็คtextBox1ว่าตรงกับcaseอะไรบ้างแล้วให้ทำตามcaseที่ตรง
            {
                /* case จะเป็นคำถามที่รับเข้ามาจากtextBox1ว่าตรงกับcaseไหน เช่น
                    case "สวัสดี":หมายถึงว่าผู้ใช้พิมคำว่า "สวัสดี" เข้ามาใน textBox1
                    *การทำงานของ case  โดยเมื่อพิมเข้ามาแล้วเราจะแสดงคำตอบกลับไปที่ label1 เช่น 
                     case "สวัสดี":label1.Text = ("สวัสดีค่ะ^^");
                     ส่วนโค้ดนี้จะเป็นแสดงรูปภาพ pictureBox1.ImageLocation = "ลิ้งค์ที่อยู่ของรูปภาพ";
                     โดยรูปภาพแต่ละรูปจะเป็นการแสดงอารมของบอทแชท(Miyuki)ซึ่งผมไม่ได้ทำไว้ทุกอันเพื่อให้มีความสมจริงแระถ้าแสดงอารมเดิมๆมากเกินไปผู้ใช้อาจจะเบื่อ
                   
                */




                case "สวัสดี":label1.Text = ("สวัสดีค่ะ^^");pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "สวัสดีจ้า": label1.Text = ("สวัสดีค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "สวัสดีค่ะ": label1.Text = ("สวัสดีค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "สวัสดีครับ": label1.Text = ("สวัสดีค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "สวัสดีครับ^^": label1.Text = ("สวัสดีค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ดีจ้า": label1.Text = ("สวัสดีค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ดีครับ": label1.Text = ("สวัสดีค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "Hi": label1.Text = ("สวัสดีค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                    //ที่ผมทำหลาย case เพราะว่ากันคำถามที่ผู้ใช้จะพิมเข้ามาซึ่งเราต้องทำการคาดเดาก่อนว่าผู้ใช้จะพิมอะไรเข้ามาบ้าง
                case "ชื่อไรอะ": label1.Text = ("ชื่อมิยูกิค่ะ"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ชื่อไรเหรอ": label1.Text = ("ชื่อมิยูกิค่ะ"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "เธอชื่อไรเหรอ": label1.Text = ("ชื่อมิยูกิค่ะ"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "เธอชื่อไรอะ": label1.Text = ("ชื่อมิยูกิค่ะ"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ชื่ออะไรอะ": label1.Text = ("ชื่อมิยูกิค่ะ"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ชื่ออะไร": label1.Text = ("ชื่อมิยูกิค่ะ"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ชื่ออะไรอะเหรอ": label1.Text = ("ชื่อมิยูกิค่ะ"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ชื่ออะไรอะเหรอครับ": label1.Text = ("ชื่อมิยูกิค่ะ"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "เธอชื่ออะไรอะเหรอ": label1.Text = ("ชื่อมิยูกิค่ะ"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;

                case "ขอแจ๊ะหน่อยสิ": label1.Text = ("แจ๊ะคืออะไรค่ะ??"); break;
                case "500นี่ซื้อได้กี่น้ำครับ": label1.Text = ("โค้ก เขียว สไปร์ ส้ม แดง จะรับน้ำอะไรค่ะ"); break;
                case "ผมของมิยูกิ มีเส้นผมกี่เส้นครับ": label1.Text = ("พอดีไม่ได้นับอะค่ะนับให้หน่อยสิค่ะ^^"); break;
                case "ขอแจ๊ะหน่อยจิ": label1.Text = ("แจ๊ะคืออะไรค่ะ??"); break;
                case "ขอแจ๊ะหน่อย": label1.Text = ("แจ๊ะคืออะไรค่ะ??"); break;
                case "ขอแจ๊ะหน่อยครับ": label1.Text = ("แจ๊ะคืออะไรค่ะ??"); break;

                case "ทำไรเหรอ": label1.Text = ("รอคำถามจากคนบางคนค่ะ^^"); break;
                case "ทำไรเหรอครับ": label1.Text = ("รอคำถามจากคนบางคนค่ะ^^"); break;
                case "ทำไรเหรอค่ะ": label1.Text = ("รอคำถามจากคนบางคนค่ะ^^"); break;
                case "ทำไรอะ": label1.Text = ("รอคำถามจากคนบางคนค่ะ^^"); break;
                case "ทำไรอะค่ะ": label1.Text = ("รอคำถามจากคนบางคนค่ะ^^"); break;
                case "ทำไรอะครับ": label1.Text = ("รอคำถามจากคนบางคนค่ะ^^"); break;

                case "มิยูกิมีแฟนยังอ่ะ": label1.Text = ("ยังค่ะทำไมเหรอค่ะ????"); break;
                case "มิยูกิมีแฟนยังเหรอ": label1.Text = ("ยังค่ะทำไมเหรอค่ะ????"); break;
                case "มีแฟนยังอ่ะ": label1.Text = ("ไม่บอกค่ะแบร่ๆ"); break;
                case "มีแฟนยัง": label1.Text = ("ไม่บอกค่ะแบร่ๆ"); break;
                case "มีแฟนยังเหรอ": label1.Text = ("ไม่บอกค่ะ^^"); break;

                case "เธอคือใคร": label1.Text = ("มิยูกิคือโปรแกรมที่มีไว้ช่วยคุยกับทุกคนค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "มิยูกิคืออะไร": label1.Text = ("มิยูกิคือโปรแกรมที่มีไว้ช่วยคุยกับทุกคนค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "มิยูกิคืออะไรเหรอ": label1.Text = ("มิยูกิคือโปรแกรมที่มีไว้ช่วยคุยกับทุกคนค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "มิยูกิคืออะไรครับ": label1.Text = ("มิยูกิคือโปรแกรมที่มีไว้ช่วยคุยกับทุกคนค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;

                case "ค้างคืนเท่าไหร่หรอ": label1.Text = ("ค้างคืน??? มิยูกิไม่ใช่โรงแรมนะค่ะ"); break;

                case "กินข้าวยังเหรอ": label1.Text = ("มิยูกิไม่กินข้าวต่ะมิยูกิเป็นโปรแกรม^^"); break;
                case "กินข้าวยังครับ": label1.Text = ("มิยูกิไม่หิวค่ะ"); break;
                case "กินข้าวยังค่ะ": label1.Text = ("มิยูกิไม่หิวค่ะ"); break;
                case "กินข้าวยัง": label1.Text = ("ยังค่ะผู้ใช้สนใจพาไปเลี้ยงไหมค่ะ^^"); break;

                case "หิวไหมอ่า": label1.Text = ("หิวสิๆเค้าอยากกินไข่เจียวแหล่ะ"); break;
                case "หิวไหมครับ": label1.Text = ("หิวสิๆ^^"); break;
                case "หิวไหมค่ะ": label1.Text = ("หิวสิๆ^^"); break;

                case "ไปกินข้าวกันไหมครับ": label1.Text = ("ไม่ค่ะมิยูกิไม่อยากไปไหนอ่า"); break;
                case "ไปกินข้าวกันไหม": label1.Text = ("ไม่ค่ะมิยูกิไม่หิว^^"); break;

                case "วันนี้ฝนจะตกไหม": label1.Text = ("ดูจากด้านข้างได้เลยค่ะ^^");  break;

                case "อายุเท่าไหร่อะ": label1.Text = ("ไม่บอกค่ะ^^"); break;
                case "อายุเท่าไหร่อะครับ": label1.Text = ("ไม่บอกค่ะ^^"); break;
                case "อายุเท่าไหร่ค่ะ": label1.Text = ("ไม่บอกค่ะ^^"); break;
                case "อายุเท่าไหร่": label1.Text = ("ไม่บอกค่ะ^^"); break;
                case "อายุกี่ปี": label1.Text = ("ไม่บอกค่ะ^^"); break;
                case "มิยูกิอายุเท่าไหร่อะ": label1.Text = ("ไม่บอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "มิยูกิอายุเท่าไหร่อะครับ": label1.Text = ("ไม่บอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "มิยูกิอายุเท่าไหร่ค่ะ": label1.Text = ("ไม่บอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "มิยูกิอายุเท่าไหร่": label1.Text = ("ไม่บอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "มิยูกิอายุกี่ปี": label1.Text = ("ไม่บอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "นี่": label1.Text = ("ค่ะ????"); break;
                case "นี่ๆ": label1.Text = ("ค่ะ????"); break;
                case "ตื่น": label1.Text = ("ค่ะ????"); break;
                case "ตื่นๆ": label1.Text = ("ค่ะ????"); break;
                case "เธอๆ": label1.Text = ("ค่ะ????"); break;
                case "เธอ": label1.Text = ("ค่ะ????"); break;
                case "ppap": label1.Text = ("I have a pen"); break;
                case "I have a apple": label1.Text = ("ohh applepen"); break;
                case "i have a apple": label1.Text = ("ohh applepen"); break;
                case "PPAP": label1.Text = ("I have a pen"); break;
                case "ppapคืออะไร": label1.Text = ("เดี๋ยวมิยูกิกำลังค้นหาค่ะ^^"); Process.Start("https://www.youtube.com/watch?v=d9TpRfDdyU0"); break;
                case "PPAPคืออะไร": label1.Text = ("เดี๋ยวมิยูกิกำลังค้นหาค่ะ^^");  Process.Start("https://www.youtube.com/watch?v=d9TpRfDdyU0"); break;
                case "ชอบฟังเพลงแนวไหน": label1.Text = ("ชอบเพลงอะนิเมค่ะ^^"); break;
                case "ชอบฟังเพลงแนวไหนเหรอ": label1.Text = ("ชอบเพลงอะนิเมค่ะ^^"); break;
                case "ชอบฟังเพลงแนวไหนหรอ": label1.Text = ("ชอบเพลงอะนิเมค่ะ^^"); break;
                case "ชอบฟังเพลงแนวไหนเหรอครับ": label1.Text = ("ชอบเพลงอะนิเมค่ะ^^"); break;
                case "ชอบเราไหม": label1.Text = ("อย่าแถมแบบนี้สิค่ะ มิยูกิ เขิลนะ><"); break;
                case "ชอบเรามะ": label1.Text = ("บ้า><ถามอะไรก็ไม่รู้"); break;
                case "มิยูกิชอบเราไหม": label1.Text = ("บ้า><ถามอะไรก็ไม่รู้"); break;
                case "เธอยังคิดถึงฉันไหม": label1.Text = ("ไม่ค่ะ^^"); break;
                case "ดอก": label1.Text = ("?????"); break;
                case "อีดอก": label1.Text = ("ชิงอลแล้ว เจอนี้เป็นไง");atk(); break;

                case "สัส": label1.Text = ("ชิงอลแล้ว เจอนี้เป็นไง");atk(); break;
                case "ควย":label1.Text = ("ชิงอลแล้ว เจอนี้เป็นไง");atk(); break;
                case "พ่อง":label1.Text = ("ชิงอลแล้ว เจอนี้เป็นไง");atk(); break;
                case "กระหรี่":label1.Text = ("ชิงอลแล้ว เจอนี้เป็นไง");atk(); break;
                case "ไปตายเถอะ":label1.Text = ("ชิงอลแล้ว เจอนี้เป็นไง"); atk(); break;

                case "มิยูกิตอบไม่ค่อยได้อะ": label1.Text = ("ขอโทษนะค่ะที่มิยูกิตอบไม่ค่อยได้ช่วยสอนมิยูกิด้วยนะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "โง่": label1.Text = ("ขอโทษนะค่ะที่มิยูกิตอบไม่ค่อยได้ช่วยสอนมิยูกิด้วยนะ^^"); break;
                case "อีโง่": label1.Text = ("ขอโทษนะค่ะที่มิยูกิตอบไม่ค่อยได้ช่วยสอนมิยูกิด้วยนะ^^"); break;
                case "ตอบไม่ค่อยได้อะ": label1.Text = ("ขอโทษนะค่ะที่มิยูกิตอบไม่ค่อยได้ช่วยสอนมิยูกิด้วยนะ^^"); break;
                case "มิยูกิตอบไม่ค่อยได้": label1.Text = ("ขอโทษนะค่ะที่มิยูกิตอบไม่ค่อยได้ช่วยสอนมิยูกิด้วยนะ^^"); break;
                case "ตอบไม่ค่อยได้": label1.Text = ("ขอโทษนะค่ะที่มิยูกิตอบไม่ค่อยได้ช่วยสอนมิยูกิด้วยนะ^^"); break;
                case "คิดว่าเราเป็นคนยังไง": label1.Text = ("เอิ่ม ไม่รุ้อะค่ะ"); break;
                case "คิดว่าผมเป็นคนยังไง": label1.Text = ("เอิ่ม ไม่รุ้อะค่ะ"); break;
                case "คิดว่าฉันเป็นคนยังไง": label1.Text = ("เอิ่ม ไม่รุ้อะค่ะ"); break;
                case "ผมหล่อไหม": label1.Text = ("ไม่ค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ผมหล่อไหมครับ": label1.Text = ("ไม่ค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ฉันสวยไหมค่ะ": label1.Text = ("สวยมั้งค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ฉันสวยไหม": label1.Text = ("ไม่ค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "เคยเสียจูบแรกยัง": label1.Text = ("ยะ ยะ ยะ ยังค่ะ "); break;
                case "โกหก": label1.Text = ("มะ มะ มะ ไม่ได้โกหกนะค่ะ "); break;
                case "ทำไมหลายมะจัง": label1.Text = ("ก็ไม่หนิค่ะ^^"); break;
                case "1+1เท่ากับเท่าไหร่": label1.Text = ("0ค่ะ"); break;
                case "1+1 เท่ากับเท่าไหร่": label1.Text = ("0ค่ะ"); break;
                case "ตอบผิด": label1.Text = ("ขอโทษด้วยนะค่ะถ้ามิยูกิตอบคำถามไหนไม่ได้สอนมิยูกิด้วยนะค่ะ^^"); break;
                case "ตอบผิดอะ": label1.Text = ("ขอโทษด้วยนะค่ะถ้ามิยูกิตอบคำถามไหนไม่ได้สอนมิยูกิด้วยนะค่ะ^^"); break;
                case "ตอบผิดอ่า": label1.Text = ("ขอโทษด้วยนะค่ะถ้ามิยูกิตอบคำถามไหนไม่ได้สอนมิยูกิด้วยนะค่ะ^^"); break;
                case "ok": label1.Text = ("ค่ะ^^"); break;
                case "OK": label1.Text = ("ค่ะ^^"); break;
                case "โอเค": label1.Text = ("ค่ะ^^"); break;
                case "โบ้ย": label1.Text = ("ค่ะ????"); break;
                case "rezeroใครเป็นนางเอก": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "rezeroใครเป็นนางเอกอ่ะ": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "rezeroใครเป็นนางเอกอ่า": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "rezeroใครเป็นนางเอกครับ": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "rezeroใครเป็นนางเอกค่ะ": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; ; break;
                case "รีซีโร่ใครเป็นนางเอก": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "รีซีโร่ใครเป็นนางเอกค่ะ": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "รีซีโร่ใครเป็นนางเอกครับ": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "รีซีโร่ใครเป็นนางเอกอะ": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "รีซีโร่ใครเป็นนางเอกอ่า": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ใครเป็นนางเอกrezero": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ใครเป็นนางเอกrezeroครับ": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ใครเป็นนางเอกrezeroค่ะ": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ใครเป็นนางเอกrezeroอ่า": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ใครเป็นนางเอกรีซีโร่": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ใครเป็นนางเอกรีซีโร่ค่ะ": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ใครเป็นนางเอกรีซีโร่ครับ": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ใครเป็นนางเอกรีซีโร่อะ": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ใครเป็นนางเอกรีซีโร่อ่า": label1.Text = ("มิยูกิเป็นนางเอกค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ไก่กับไข่อะไรเกิดก่อนกัน": label1.Text = ("เอิ่ม ...... ไม่รู้ค่ะ"); break;
                case "ประเทศอะไรร้อนที่สุดในโลก": label1.Text = ("ประเทศไทยค่ะ"); break;
                case "ประเทศอะไรร้อนที่สุด": label1.Text = ("ประเทศไทยค่ะ"); break;
                case "A-Zมีกี่ตัว": label1.Text = ("26ค่ะ"); break;
                case "ตกลงตานี่เอาไว้มองหรือเอาไว้เป็นเผายาย": label1.Text = ("ตามี2ตาค่ะ=.="); break;
                case "สาวแว่นกับสาวทวิลเทลอะไรน่ารักกว่ากัน": label1.Text = ("สาวแว่นค่ะค่ะ"); break;
                case "รีซีโร่ทั้งเรื่องพระเอกตายกี่ครั้ง": label1.Text = ("เอิ่ม...ไม่ได้นับค่ะ"); break;
                case "Rezeroทั้งเรื่องพระเอกตายกี่ครั้ง": label1.Text = ("เอิ่ม...ไม่ได้นับค่ะ"); break;
                case "rezeroทั้งเรื่องพระเอกตายกี่ครั้ง": label1.Text = ("เอิ่ม...ไม่ได้นับค่ะ"); break;
                case "Taคนไหนน่ากลัวที่สุด": label1.Text = ("เอิ่ม...ไม่ขอตอบนะค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "taคนไหนน่ากลัวที่สุด": label1.Text = ("เอิ่ม...ไม่ขอตอบนะค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ทีเอคนไหนน่ากลัวที่สุด": label1.Text = ("เอิ่ม...ไม่ขอตอบนะค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "ทีเอคนไหนใจร้ายที่สุด": label1.Text = ("เอิ่ม...ไม่ขอตอบนะค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "Taคนไหนใจร้ายที่สุด": label1.Text = ("เอิ่ม...ไม่ขอตอบนะค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "taคนไหนใจร้ายที่สุด": label1.Text = ("เอิ่ม...ไม่ขอตอบนะค่ะ^^"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15181539_1261686290560169_6271435040142870065_n.png?oh=0c6e178bfb404e348447d73b03bb6a70&oe=58FB113C"; break;
                case "พี่แต้วสวยไหม": label1.Text = ("มิยูกิว่ามิยูกิสวยกว่านะค่ะ^^"); break;
                case "พี่พจน์หล่อไหม": label1.Text = ("เอิ่มหล่อมั้งค่ะ^^"); break;
                case "พี่พจหล่อไหม": label1.Text = ("เอิ่มหล่อมั้งค่ะ^^"); break;
                case "มีผัวไหม": label1.Text = ("ไม่มีค่ะ...."); break;
                case "ชอบกินอาหารอะไรเป็นพิเศษครับ": label1.Text = ("ชอบกินข้าวค่ะ"); break;
                case "ชอบผู้ชายแบบไหน": label1.Text = ("ชอบผู้ชายที่เป็นผู้ชายค่ะ"); break;
                case "อาร์มชอบเรทกี่นาที": label1.Text = ("เป็นชั่วโมงเลยค่ะ"); break;
                case "เอิร์ทชอบเรทกี่นาที": label1.Text = ("เป็นชั่วโมงเลยค่ะ"); break;
                case "เอิ้นชอบเรทกี่นาที": label1.Text = ("เป็นชั่วโมงเลยค่ะ"); break;
                case "สิงโตชอบเรทกี่นาที": label1.Text = ("เป็นชั่วโมงเลยค่ะ"); break;
                case "แม็กก้าชอบเรทกี่นาที": label1.Text = ("ไม่เรทเลยค่ะ^^"); break;
                case "ต๋องชอบเรทกี่นาที": label1.Text = ("เป็นชั่วโมงเลยค่ะ"); break;
                case "โดนัทชอบเรทกี่นาที": label1.Text = ("เป็นชั่วโมงเลยค่ะ"); break;
                case "วันพีชมีกี่ชิ้น": label1.Text = ("หลายตอนค่ะ"); break;
                case "ดาวตกในคิมิโนนาวาชื่อว่าอะไร": label1.Text = ("Tiamusค่ะ"); break;
                case "ขอเบอร์หน่อย": label1.Text = ("39ค่ะ^^"); break;
                case "ขอเบอร์ได้ไหม": label1.Text = ("39ค่ะ^^"); break;
                case "ขอเบอร์หน่อยสิ": label1.Text = ("39ค่ะ^^"); break;
                case "ดิจ้า": label1.Text = ("สวัสดีค่ะ^^"); break;
                case "จีบได้ไหม": label1.Text = ("ได้ค่ะแต่ต้องสอนมิยูกิบ่อยๆน้า^^"); break;
                case "จีบได้ปะ": label1.Text = ("ได้ค่ะแต่ต้องสอนมิยูกิบ่อยๆน้า^^"); break;
                case "ทำไมใส่แว่น": label1.Text = ("คนสร้างชอบสาวแว่นค่ะ^^"); break;
                case "ทำไมใส่แว่นอะ": label1.Text = ("คนสร้างชอบสาวแว่นค่ะ^^"); break;
                case "ทำไมใส่แว่นอะครับ": label1.Text = ("คนสร้างชอบสาวแว่นค่ะ^^"); break;
                case "ทำไมใส่แว่นเหรอ": label1.Text = ("คนสร้างชอบสาวแว่นค่ะ^^"); break;
                case "ทำไมใส่แว่นหรอ": label1.Text = ("คนสร้างชอบสาวแว่นค่ะ^^"); break;
                case "ทำไมผมสั้น": label1.Text = ("ไม่รู้ค่ะถามคนสร้างมิยุกินะค่ะ^^"); break;
                case "เวลาเท่าไหร่": label1.Text = DateTime.Now.ToString("ตอนนี้เวลา"+"h:mm:ss tt" +"ค่ะ"); break;
                case "เวลาเท่าไหร่เหรอ": label1.Text = DateTime.Now.ToString("ตอนนี้เวลา" + "h:mm:ss tt" + "ค่ะ"); break;
                case "เวลาเท่าไหร่อะ": label1.Text = DateTime.Now.ToString("ตอนนี้เวลา" + "h:mm:ss tt" + "ค่ะ"); break;
                case "กี่โมงแล้ว": label1.Text = DateTime.Now.ToString("ตอนนี้เวลา" + "h:mm:ss tt" + "ค่ะ"); break;
                case "มิยูกิทำอะไรได้บ้าง": label1.Text = ("ตอนนี้ก็ได้แค่ถามตอบค่ะ^^"); break;
                case "พอจะมีสัก200ไหม": label1.Text =("เอาไปทำไมค่ะ???"); break;
                case "พอจะมีสักสองร้อยไหม": label1.Text = ("เอาไปทำไมค่ะ???"); break;
                case "รู้เหมือไร่": label1.Text = ("มันคืออะไรค่ะ???"); break;
                case "คิดถึงจัง": label1.Text = ("คะ คะ คิดถึงมิยูกิเหรอค่ะ???"); break;
                case "คิดถึง": label1.Text = ("คะ คะ คิดถึงมิยูกิเหรอค่ะ???"); break;
                case "คิดถึงนะ": label1.Text = ("คะ คะ คิดถึงมิยูกิเหรอค่ะ???"); break;
                case "ถ้าวันหนึ่งผมหายไปจะเป็นยังไง": label1.Text = ("ใครจะหายเหรอค่ะ???"); break;
                case "ผมเอง": label1.Text = ("ทำไมเหรอ?"); break;
                case "ไม่มีใครสนใจ": label1.Text = ("มิยูกิยังอยู่ข้างๆนะค่ะ^^"); break;
                case "การบ้านยากจัง": label1.Text = ("เนอะค่ะ^^"); break;
                case "ขอบคุณนะ": label1.Text = ("ไม่เป็นไรค่ะ^^"); break;
                case "เฮ้อ": label1.Text = ("เป็นไรค่ะ????"); break;
                case "เฮ้อ...": label1.Text = ("เป็นไรค่ะ????"); break;
                case "ทำไมสวยจัง": label1.Text = ("สะ สะ สวยเหรอ??"); break;
                case "พ่อชื่ออะไร": label1.Text = ("แม็กก้าค่ะ^^"); break;
                case "แม่ชื่ออะไร": label1.Text = ("อันนี้ต้องถามพ่อมิยูกินะค่ะ^^"); break;
                case "ใครเป็นคนสร้าง": label1.Text = ("ชื่อว่าแม็กก้าค่ะ^^"); Process.Start("https://www.facebook.com/maxga.maxshin"); break;
                case "ใครเป็นคนสร้างมิยูกิ": label1.Text = ("ชื่อว่าแม็กก้าค่ะ^^"); Process.Start("https://www.facebook.com/maxga.maxshin"); break;
                case "ใช่": label1.Text = ("ค่ะ^^");  break;
                case "ใช่ๆ": label1.Text = ("ค่ะ^^"); break;
                case "ใช่ครับ": label1.Text = ("ค่ะ^^"); break;
                case "ใช่ครับๆ": label1.Text = ("ค่ะ^^"); break;














                //คำสั่งต่อจากนี้จะเป็นคำสั่งเปิดโปรแกรมในเครื่องซึ่งจะเป็นการเรียกโปรแกรมในเครื่องขึ้นมาโดยตำสั่ง  Process.Start("ที่อยู่ของโปรแกรมภายในเครื่อง");
                case "เปิด Google Chrome": label1.Text = ("มิยูกิกำลังทำการเปิดโปรแกรมค่ะ^^"); Process.Start("C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe"); break;
                case "เปิด word": label1.Text = ("มิยูกิกำลังทำการเปิดโปรแกรมค่ะ^^"); Process.Start("https://login.microsoftonline.com/login.srf?wa=wsignin1.0&rpsnv=4&ct=1472464068&rver=6.7.6640.0&wp=MCMBI&wreply=https%3a%2f%2fportal.office.com%2flanding.aspx%3ftarget%3d%252fonedrive%253fmsafed%253d0&lc=1054&id=501392&msafed=0&client-request-id=fa0a5a96-b205-41b7-b332-cb3afd5b8d51"); break;
                case "เปิด excel": label1.Text = ("มิยูกิกำลังทำการเปิดโปรแกรมค่ะ^^"); Process.Start("https://login.microsoftonline.com/login.srf?wa=wsignin1.0&rpsnv=4&ct=1472464068&rver=6.7.6640.0&wp=MCMBI&wreply=https%3a%2f%2fportal.office.com%2flanding.aspx%3ftarget%3d%252fonedrive%253fmsafed%253d0&lc=1054&id=501392&msafed=0&client-request-id=fa0a5a96-b205-41b7-b332-cb3afd5b8d51"); break;
                case "เปิด powerpoin": label1.Text = ("มิยูกิกำลังทำการเปิดโปรแกรมค่ะ^^"); Process.Start("https://login.microsoftonline.com/login.srf?wa=wsignin1.0&rpsnv=4&ct=1472464068&rver=6.7.6640.0&wp=MCMBI&wreply=https%3a%2f%2fportal.office.com%2flanding.aspx%3ftarget%3d%252fonedrive%253fmsafed%253d0&lc=1054&id=501392&msafed=0&client-request-id=fa0a5a96-b205-41b7-b332-cb3afd5b8d51"); break;
                case "เปิด o365": label1.Text = ("มิยูกิกำลังทำการเปิดโปรแกรมค่ะ^^"); Process.Start("https://login.microsoftonline.com/login.srf?wa=wsignin1.0&rpsnv=4&ct=1472464068&rver=6.7.6640.0&wp=MCMBI&wreply=https%3a%2f%2fportal.office.com%2flanding.aspx%3ftarget%3d%252fonedrive%253fmsafed%253d0&lc=1054&id=501392&msafed=0&client-request-id=fa0a5a96-b205-41b7-b332-cb3afd5b8d51"); break;


                //คำสั่งต่อจากนี้จะเป็นคำสั่งให้เปิดwebขึ้นมาโดยจะใช้คำสั่ง Process.Start("ลิ้งค์เว็บ");
                case "Youtube": label1.Text = ("มิยูกิกำลังทำการเปิดเว็บไซต์ค่ะ^^"); Process.Start("https://www.youtube.com"); break;
                case "youtube": label1.Text = ("มิยูกิกำลังทำการเปิดเว็บไซต์ค่ะ^^"); Process.Start("https://www.youtube.com"); break;
                case "Google": label1.Text = ("มิยูกิกำลังทำการเปิดเว็บไซต์ค่ะ^^"); Process.Start("https://www.Google.co.th"); break;
                case "google": label1.Text = ("มิยูกิกำลังทำการเปิดเว็บไซต์ค่ะ^^"); Process.Start("https://www.Google.co.th"); break;
                case "facebook": label1.Text = ("มิยูกิกำลังทำการเปิดเว็บไซต์ค่ะ^^"); Process.Start("https://www.facebook.com"); break;
                case "Facebook": label1.Text = ("มิยูกิกำลังทำการเปิดเว็บไซต์ค่ะ^^"); Process.Start("https://www.facebook.com"); break;
                case "kku": label1.Text = ("มิยูกิกำลังทำการเปิดเว็บไซต์ค่ะ^^"); Process.Start("http://reg.kku.ac.th/"); break;
                case "KKU": label1.Text = ("มิยูกิกำลังทำการเปิดเว็บไซต์ค่ะ^^"); Process.Start("http://reg.kku.ac.th/"); break;

                //หากผู้ใช้พิมสิ่งที่ไม่ตรงกับ case ที่เรากำหนดไว้จะให้บอทแชทตอบไปว่า "ไม่เข้าใจในคำถามกรุณากรอกคำถามใหม่ค่ะ"
                default: label1.Text = ("ไม่เข้าใจในคำถามกรุณากรอกคำถามใหม่ค่ะ"); pictureBox1.ImageLocation = "https://scontent.fbkk2-3.fna.fbcdn.net/v/t1.0-9/15253640_1261686187226846_450220227878351422_n.png?oh=a0dcbd474ea2ba362be9165e30a4d847&oe=58F80EBF "; break;

            }
            
        }

        private void button2_Click(object sender, EventArgs e)//เมื่อ button2 คลิ๊ก(ปุ่มเพิ่มคำถาม)
        {
            Process.Start("https://docs.google.com/forms/d/e/1FAIpQLSe6fd-9550gnk6OFEwqkMQoWdKPg9kXyzz0O7sypALP-v3rug/viewform");
            //จะทำกาเปิดเว็บไปที่googleฟอมเพื่อรับคำถามที่ต้องการให้แอดมินเพิ่มซึ่งเราจะเข้าไปเพิ่มและอัพเดตให้ในเวลาถัดไป

        }

        private void pictureBox2_Click(object sender, EventArgs e)//เมื่อpictureBox2ถูกคลิ๊ก(รูปfacebook)
        {
            Process.Start("https://www.facebook.com/Miyuki-1222180967844035/");//จะทำการเปิดwebไปที่เพจmiyukiที่ทางแอดมินทำไว้
        }

        private void button3_Click(object sender, EventArgs e)
        {

            
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)//หากเรากด คีย์อะไร ขณะที่พิมพ์ใน textBox1 
        {
            if (e.KeyCode == Keys.Enter)//ถ้าเรากด Enter
            {
                button1_Click(sender, EventArgs.Empty);//เรียกใช้คำสั่งเสมือนว่า button1 ถูกคลิ๊ก
                textBox1.Text = ""; //แสดงtextBox1ให้ว่างไว้
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            /*  ในส่วนของพยากรณ์อาการณ์ผมใช้webBrowserในการทำให้โชว์ web และเว็บที่ใช้คือ 
            https://www.google.co.th/search?q=%E0%B8%9E%E0%B8%A2%E0%B8%B2%E0%B8%81%E0%B8%A3%E0%B8%93%E0%B9%8C%E0%B8%AD%E0%B8%B2%E0%B8%81%E0%B8%B2%E0%B8%A8&rlz=1C1CHBF_thTH700TH701&oq=%E0%B8%9E%E0%B8%A2%E0%B8%B2%E0%B8%81&aqs=chrome.1.69i57j69i59.3399j0j7&sourceid=chrome&ie=UTF-8
            googleพยากรรอากาณ์ 
            แล้วผมก็ย่อให้มันพอดีกับขนาดหน้าต่างแล้วตั้งให้ไม่สามารถเลื่อนเว็บได้ครับ

            */
        }
    }
}
